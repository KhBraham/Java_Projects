package com.exemple1.java;
public class CouleurValideException extends Exception {
    public CouleurValideException() {
        super("La couleur est invalide.");
    }
}